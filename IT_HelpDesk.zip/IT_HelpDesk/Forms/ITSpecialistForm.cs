﻿using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using IT_HelpDesk.Helpers;
using IT_HelpDesk.Models;
using IT_HelpDesk.Services;

namespace IT_HelpDesk.Forms
{
    public partial class ITSpecialistForm : Form
    {
        private User _currentUser;
        private RequestService _requestService;

        public ITSpecialistForm(User user)
        {
            _currentUser = user;
            _requestService = new RequestService();
            InitializeComponent();
            LoadRequests();
            UpdateStats();
        }

        private void LoadRequests()
        {
            var requests = _requestService.GetRequestsForUser(_currentUser).ToList();
            string filter = cmbStatusFilter.SelectedItem?.ToString();
            if (filter != null && filter != "Все")
                requests = requests.Where(r => r.Status == filter).ToList();

            dgvRequests.DataSource = requests;

            if (dgvRequests.Columns.Contains("Id")) dgvRequests.Columns["Id"].HeaderText = "№";
            if (dgvRequests.Columns.Contains("UserName")) dgvRequests.Columns["UserName"].HeaderText = "Заявитель";
            if (dgvRequests.Columns.Contains("ProblemDesc")) dgvRequests.Columns["ProblemDesc"].HeaderText = "Описание";
            if (dgvRequests.Columns.Contains("CreatedAt")) dgvRequests.Columns["CreatedAt"].HeaderText = "Дата";
            if (dgvRequests.Columns.Contains("Status")) dgvRequests.Columns["Status"].HeaderText = "Статус";
            if (dgvRequests.Columns.Contains("PriorityName")) dgvRequests.Columns["PriorityName"].HeaderText = "Приоритет";
            if (dgvRequests.Columns.Contains("CategoryName")) dgvRequests.Columns["CategoryName"].HeaderText = "Категория";
        }

        private void UpdateStats()
        {
            var all = _requestService.GetRequestsForUser(_currentUser).ToList();
            lblNewCount.Text = all.Count(r => r.Status == "New").ToString();
            lblInProgressCount.Text = all.Count(r => r.Status == "InProgress").ToString();
            lblTotalCount.Text = all.Count().ToString();
        }

        private void OpenDetails()
        {
            if (dgvRequests.CurrentRow != null)
            {
                int id = (int)dgvRequests.CurrentRow.Cells["Id"].Value;
                var detailsForm = new RequestDetailsForm(id, _currentUser);
                detailsForm.ShowDialog();
                LoadRequests();
                UpdateStats();
            }
        }

        private void BtnResolve_Click(object sender, EventArgs e)
        {
            if (dgvRequests.CurrentRow == null)
            {
                FormHelper.ShowWarning("Выберите заявку!");
                return;
            }

            int requestId = (int)dgvRequests.CurrentRow.Cells["Id"].Value;
            string currentStatus = dgvRequests.CurrentRow.Cells["Status"].Value?.ToString();

            if (currentStatus == "Resolved" || currentStatus == "Closed")
            {
                FormHelper.ShowWarning("Эта заявка уже решена или закрыта!");
                return;
            }

            string solutionText = ShowInputDialog();

            if (!string.IsNullOrWhiteSpace(solutionText))
            {
                try
                {
                    _requestService.AddSolution(requestId, _currentUser.Id, solutionText);
                    FormHelper.ShowInfo("Заявка успешно решена!");
                    LoadRequests();
                    UpdateStats();
                }
                catch (Exception ex)
                {
                    FormHelper.ShowError($"Ошибка: {ex.Message}");
                }
            }
        }

        private string ShowInputDialog()
        {
            Form dialog = new Form();
            dialog.Text = "Решение заявки";
            dialog.Size = new Size(500, 250);
            dialog.StartPosition = FormStartPosition.CenterParent;
            dialog.FormBorderStyle = FormBorderStyle.FixedDialog;
            dialog.BackColor = FormHelper.WhitePastel;

            Label label = new Label();
            label.Text = "Введите описание решения:";
            label.Font = new Font("Segoe UI", 11, FontStyle.Bold);
            label.Location = new Point(20, 20);
            label.Size = new Size(440, 25);

            TextBox textBox = new TextBox();
            textBox.Location = new Point(20, 55);
            textBox.Size = new Size(440, 90);
            textBox.Multiline = true;
            FormHelper.StyleTextBox(textBox, true);

            Button okButton = new Button();
            okButton.Text = "Решить";
            okButton.Location = new Point(280, 160);
            okButton.Size = new Size(170, 40);
            FormHelper.StyleButton(okButton, FormHelper.SuccessPastel);
            okButton.DialogResult = DialogResult.OK;

            Button cancelButton = new Button();
            cancelButton.Text = "Отмена";
            cancelButton.Location = new Point(90, 160);
            cancelButton.Size = new Size(170, 40);
            FormHelper.StyleButton(cancelButton, FormHelper.GrayPastel);
            cancelButton.DialogResult = DialogResult.Cancel;

            dialog.Controls.Add(label);
            dialog.Controls.Add(textBox);
            dialog.Controls.Add(okButton);
            dialog.Controls.Add(cancelButton);

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                return textBox.Text;
            }
            return string.Empty;
        }

        private void BtnRefresh_Click(object sender, EventArgs e)
        {
            LoadRequests();
            UpdateStats();
            FormHelper.ShowInfo("Данные обновлены");
        }

        private void BtnViewDetails_Click(object sender, EventArgs e)
        {
            OpenDetails();
        }

        private void DgvRequests_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
                OpenDetails();
        }

        private void CmbStatusFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadRequests();
        }
    }
}