﻿using System;
using System.Linq;
using System.Windows.Forms;
using IT_HelpDesk.Models;
using IT_HelpDesk.Services;
using IT_HelpDesk.Helpers;

namespace IT_HelpDesk.Forms
{
    public partial class EmployeeForm : Form
    {
        private User _currentUser;
        private RequestService _requestService;

        public EmployeeForm(User user)
        {
            _currentUser = user;
            _requestService = new RequestService();
            InitializeComponent();
            LoadPrioritiesAndCategories();
            LoadRequests();
            UpdateStats();
        }

        private void LoadPrioritiesAndCategories()
        {
            cmbPriority.DataSource = _requestService.GetAllPriorities().ToList();
            cmbPriority.DisplayMember = "Name";
            cmbPriority.ValueMember = "Id";

            cmbCategory.DataSource = _requestService.GetAllCategories().ToList();
            cmbCategory.DisplayMember = "Name";
            cmbCategory.ValueMember = "Id";
        }

        private void LoadRequests()
        {
            var requests = _requestService.GetRequestsForUser(_currentUser).ToList();
            dgvRequests.DataSource = requests;

            if (dgvRequests.Columns.Contains("Id")) dgvRequests.Columns["Id"].HeaderText = "№";
            if (dgvRequests.Columns.Contains("ProblemDesc")) dgvRequests.Columns["ProblemDesc"].HeaderText = "Описание";
            if (dgvRequests.Columns.Contains("CreatedAt")) dgvRequests.Columns["CreatedAt"].HeaderText = "Дата";
            if (dgvRequests.Columns.Contains("Status")) dgvRequests.Columns["Status"].HeaderText = "Статус";
            if (dgvRequests.Columns.Contains("PriorityName")) dgvRequests.Columns["PriorityName"].HeaderText = "Приоритет";
            if (dgvRequests.Columns.Contains("CategoryName")) dgvRequests.Columns["CategoryName"].HeaderText = "Категория";
        }

        private void UpdateStats()
        {
            var requests = _requestService.GetRequestsForUser(_currentUser);
            lblStats.Text = $"Всего заявок: {requests.Count()} | Активных: {requests.Count(r => r.Status != "Resolved" && r.Status != "Closed")}";
        }

        private void BtnCreate_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtProblemDesc.Text))
            {
                FormHelper.ShowWarning("Введите описание проблемы");
                return;
            }

            _requestService.CreateRequest(_currentUser.Id, txtProblemDesc.Text, (int)cmbPriority.SelectedValue, (int)cmbCategory.SelectedValue);
            FormHelper.ShowInfo("Заявка создана");
            txtProblemDesc.Clear();
            LoadRequests();
            UpdateStats();
        }

        private void OpenDetails()
        {
            if (dgvRequests.CurrentRow != null)
            {
                int id = (int)dgvRequests.CurrentRow.Cells["Id"].Value;
                var detailsForm = new RequestDetailsForm(id, _currentUser);
                detailsForm.ShowDialog();
                LoadRequests();
                UpdateStats();
            }
        }

        private void BtnRefresh_Click(object sender, EventArgs e)
        {
            LoadRequests();
            UpdateStats();
            FormHelper.ShowInfo("Данные обновлены");
        }

        private void BtnViewDetails_Click(object sender, EventArgs e)
        {
            OpenDetails();
        }

        private void DgvRequests_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
                OpenDetails();
        }
    }
}