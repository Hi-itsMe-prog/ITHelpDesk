﻿using System.Drawing;
using System.Windows.Forms;
using IT_HelpDesk.Helpers;

namespace IT_HelpDesk.Forms
{
    partial class EmployeeForm
    {
        private DataGridView dgvRequests;
        private TextBox txtProblemDesc;
        private ComboBox cmbPriority;
        private ComboBox cmbCategory;
        private Button btnCreate;
        private Button btnRefresh;
        private Button btnViewDetails;
        private Label lblStats;

        private void InitializeComponent()
        {
            FormHelper.StyleForm(this);
            this.Size = new Size(1000, 680);
            this.MinimumSize = new Size(900, 600);
            this.Text = $"IT Help Desk - {_currentUser.FullName}";
            this.BackColor = FormHelper.LightPastel;

            // ========== ВЕРХНЯЯ ПАНЕЛЬ ==========
            Label lblTitle = new Label();
            lblTitle.Text = $"Здравствуйте, {_currentUser.FullName}";
            lblTitle.Font = new Font("Segoe UI", 14, FontStyle.Bold);
            lblTitle.ForeColor = FormHelper.DarkPastel;
            lblTitle.Location = new Point(20, 20);
            lblTitle.Size = new Size(500, 30);

            lblStats = new Label();
            lblStats.Text = "Загрузка...";
            lblStats.Font = new Font("Segoe UI", 10);
            lblStats.ForeColor = FormHelper.GrayPastel;
            lblStats.Location = new Point(20, 55);
            lblStats.Size = new Size(400, 25);

            btnRefresh = new Button();
            btnRefresh.Text = "Обновить";
            btnRefresh.Location = new Point(830, 20);
            btnRefresh.Size = new Size(130, 40);
            FormHelper.StyleButton(btnRefresh, FormHelper.GrayPastel);
            btnRefresh.Click += BtnRefresh_Click;

            // ========== ТАБЛИЦА ЗАЯВОК ==========
            dgvRequests = new DataGridView();
            dgvRequests.Location = new Point(20, 95);
            dgvRequests.Size = new Size(940, 260);
            dgvRequests.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            FormHelper.ConfigureDataGridView(dgvRequests);
            dgvRequests.CellDoubleClick += DgvRequests_CellDoubleClick;

            // ========== КНОПКИ ПОД ТАБЛИЦЕЙ ==========
            btnViewDetails = new Button();
            btnViewDetails.Text = "Подробнее";
            btnViewDetails.Location = new Point(20, 370);
            btnViewDetails.Size = new Size(160, 40);
            FormHelper.StyleButton(btnViewDetails, FormHelper.PrimaryPastel);
            btnViewDetails.Click += BtnViewDetails_Click;

            // ========== ПАНЕЛЬ СОЗДАНИЯ ЗАЯВКИ ==========
            GroupBox gbCreate = new GroupBox();
            gbCreate.Text = "Создать новую заявку";
            gbCreate.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            gbCreate.Location = new Point(20, 430);
            gbCreate.Size = new Size(940, 200);
            gbCreate.BackColor = FormHelper.WhitePastel;

            // Описание проблемы
            Label lblProblem = new Label();
            lblProblem.Text = "Описание проблемы:";
            lblProblem.Font = new Font("Segoe UI", 9, FontStyle.Bold);
            lblProblem.Location = new Point(15, 30);
            lblProblem.Size = new Size(120, 25);

            txtProblemDesc = new TextBox();
            txtProblemDesc.Location = new Point(140, 30);
            txtProblemDesc.Size = new Size(500, 70);
            txtProblemDesc.Multiline = true;
            FormHelper.StyleTextBox(txtProblemDesc, true);

            // Приоритет
            Label lblPriority = new Label();
            lblPriority.Text = "Приоритет:";
            lblPriority.Font = new Font("Segoe UI", 9, FontStyle.Bold);
            lblPriority.Location = new Point(15, 115);
            lblPriority.Size = new Size(80, 25);

            cmbPriority = new ComboBox();
            cmbPriority.Location = new Point(100, 112);
            cmbPriority.Size = new Size(180, 30);
            FormHelper.StyleComboBox(cmbPriority);

            // Категория
            Label lblCategory = new Label();
            lblCategory.Text = "Категория:";
            lblCategory.Font = new Font("Segoe UI", 9, FontStyle.Bold);
            lblCategory.Location = new Point(310, 115);
            lblCategory.Size = new Size(80, 25);

            cmbCategory = new ComboBox();
            cmbCategory.Location = new Point(395, 112);
            cmbCategory.Size = new Size(180, 30);
            FormHelper.StyleComboBox(cmbCategory);

            // Кнопка создания
            btnCreate = new Button();
            btnCreate.Text = "Создать заявку";
            btnCreate.Location = new Point(650, 110);
            btnCreate.Size = new Size(180, 40);
            FormHelper.StyleButton(btnCreate, FormHelper.SuccessPastel);
            btnCreate.Click += BtnCreate_Click;

            gbCreate.Controls.Add(lblProblem);
            gbCreate.Controls.Add(txtProblemDesc);
            gbCreate.Controls.Add(lblPriority);
            gbCreate.Controls.Add(cmbPriority);
            gbCreate.Controls.Add(lblCategory);
            gbCreate.Controls.Add(cmbCategory);
            gbCreate.Controls.Add(btnCreate);

            // ========== ДОБАВЛЯЕМ ВСЕ КОНТРОЛЫ ==========
            this.Controls.Add(lblTitle);
            this.Controls.Add(lblStats);
            this.Controls.Add(btnRefresh);
            this.Controls.Add(dgvRequests);
            this.Controls.Add(btnViewDetails);
            this.Controls.Add(gbCreate);
        }
    }
}