﻿using System.Drawing;
using System.Windows.Forms;
using IT_HelpDesk.Helpers;

namespace IT_HelpDesk.Forms
{
    partial class ITSpecialistForm
    {
        private DataGridView dgvRequests;
        private ComboBox cmbStatusFilter;
        private Button btnRefresh;
        private Button btnViewDetails;
        private Button btnResolve;
        private Label lblNewCount;
        private Label lblInProgressCount;
        private Label lblTotalCount;

        private void InitializeComponent()
        {
            FormHelper.StyleForm(this);
            this.Size = new Size(1100, 650);
            this.Text = $"IT Help Desk - IT Специалист: {_currentUser.FullName}";
            this.BackColor = FormHelper.LightPastel;

            // ========== ЗАГОЛОВОК ==========
            Label lblTitle = new Label();
            lblTitle.Text = $"IT Специалист: {_currentUser.FullName}";
            lblTitle.Font = new Font("Segoe UI", 14, FontStyle.Bold);
            lblTitle.ForeColor = FormHelper.DarkPastel;
            lblTitle.Location = new Point(20, 20);
            lblTitle.Size = new Size(500, 30);

            // ========== ПАНЕЛЬ СТАТИСТИКИ ==========
            Panel pnlStats = new Panel();
            pnlStats.Location = new Point(20, 60);
            pnlStats.Size = new Size(1040, 80);

            // Карточка 1: Новые заявки
            Panel cardNew = CreateStatCard("Новые заявки", ref lblNewCount, FormHelper.DangerPastel);
            cardNew.Location = new Point(0, 0);

            // Карточка 2: В работе
            Panel cardProgress = CreateStatCard("В работе", ref lblInProgressCount, FormHelper.WarningPastel);
            cardProgress.Location = new Point(210, 0);

            // Карточка 3: Всего заявок
            Panel cardTotal = CreateStatCard("Всего заявок", ref lblTotalCount, FormHelper.PrimaryPastel);
            cardTotal.Location = new Point(420, 0);

            pnlStats.Controls.Add(cardNew);
            pnlStats.Controls.Add(cardProgress);
            pnlStats.Controls.Add(cardTotal);

            // ========== ФИЛЬТР ==========
            Label lblFilter = new Label();
            lblFilter.Text = "Фильтр по статусу:";
            lblFilter.Location = new Point(20, 155);
            lblFilter.Size = new Size(120, 25);

            cmbStatusFilter = new ComboBox();
            cmbStatusFilter.Location = new Point(145, 152);
            cmbStatusFilter.Size = new Size(150, 34);
            FormHelper.StyleComboBox(cmbStatusFilter);
            cmbStatusFilter.Items.AddRange(new object[] { "Все", "New", "InProgress", "Resolved", "Closed" });
            cmbStatusFilter.SelectedIndex = 0;
            cmbStatusFilter.SelectedIndexChanged += CmbStatusFilter_SelectedIndexChanged;

            btnRefresh = new Button();
            btnRefresh.Text = "Обновить";
            btnRefresh.Location = new Point(900, 150);
            btnRefresh.Size = new Size(160, 40);
            FormHelper.StyleButton(btnRefresh, FormHelper.GrayPastel);
            btnRefresh.Click += BtnRefresh_Click;

            // ========== ТАБЛИЦА ==========
            dgvRequests = new DataGridView();
            dgvRequests.Location = new Point(20, 200);
            dgvRequests.Size = new Size(1040, 320);
            FormHelper.ConfigureDataGridView(dgvRequests);
            dgvRequests.CellDoubleClick += DgvRequests_CellDoubleClick;

            // ========== КНОПКИ ==========
            btnViewDetails = new Button();
            btnViewDetails.Text = "Подробнее";
            btnViewDetails.Location = new Point(20, 540);
            btnViewDetails.Size = new Size(160, 40);
            FormHelper.StyleButton(btnViewDetails, FormHelper.PrimaryPastel);
            btnViewDetails.Click += BtnViewDetails_Click;

            btnResolve = new Button();
            btnResolve.Text = "Решить заявку";
            btnResolve.Location = new Point(200, 540);
            btnResolve.Size = new Size(160, 40);
            FormHelper.StyleButton(btnResolve, FormHelper.SuccessPastel);
            btnResolve.Click += BtnResolve_Click;

            // ========== ДОБАВЛЯЕМ КОНТРОЛЫ ==========
            this.Controls.Add(lblTitle);
            this.Controls.Add(pnlStats);
            this.Controls.Add(lblFilter);
            this.Controls.Add(cmbStatusFilter);
            this.Controls.Add(btnRefresh);
            this.Controls.Add(dgvRequests);
            this.Controls.Add(btnViewDetails);
            this.Controls.Add(btnResolve);
        }

        private Panel CreateStatCard(string title, ref Label valueLabel, Color color)
        {
            Panel card = new Panel();
            card.Size = new Size(190, 75);
            card.BackColor = FormHelper.WhitePastel;

            Label lblTitle = new Label();
            lblTitle.Text = title;
            lblTitle.Font = new Font("Segoe UI", 10);
            lblTitle.ForeColor = FormHelper.GrayPastel;
            lblTitle.Location = new Point(12, 10);
            lblTitle.Size = new Size(170, 22);

            valueLabel = new Label();
            valueLabel.Text = "0";
            valueLabel.Font = new Font("Segoe UI", 22, FontStyle.Bold);
            valueLabel.ForeColor = FormHelper.DarkPastel;
            valueLabel.Location = new Point(12, 32);
            valueLabel.Size = new Size(170, 38);
            valueLabel.TextAlign = ContentAlignment.MiddleLeft;

            card.Controls.Add(lblTitle);
            card.Controls.Add(valueLabel);

            return card;
        }
    }
}