﻿using System.Drawing;
using System.Windows.Forms;
using IT_HelpDesk.Helpers;

namespace IT_HelpDesk.Forms
{
    partial class LoginForm
    {
        private TextBox txtLogin;
        private TextBox txtPassword;
        private Button btnLogin;
        private Button btnExit;

        private void InitializeComponent()
        {
            FormHelper.StyleForm(this);
            this.Size = new Size(400, 350);
            this.Text = "IT Help Desk - Вход";
            this.BackColor = FormHelper.LightPastel;

            Label lblTitle = new Label();
            lblTitle.Text = "IT Help Desk";
            lblTitle.Font = new Font("Segoe UI", 20, FontStyle.Bold);
            lblTitle.ForeColor = FormHelper.DarkPastel;
            lblTitle.Location = new Point(50, 30);
            lblTitle.Size = new Size(300, 45);
            lblTitle.TextAlign = ContentAlignment.MiddleCenter;

            Label lblLogin = new Label();
            lblLogin.Text = "Логин";
            lblLogin.Font = new Font("Segoe UI", 9, FontStyle.Bold);
            lblLogin.ForeColor = FormHelper.DarkPastel;
            lblLogin.Location = new Point(50, 100);
            lblLogin.Size = new Size(300, 20);

            txtLogin = new TextBox();
            txtLogin.Font = new Font("Segoe UI", 11);
            txtLogin.Location = new Point(50, 125);
            txtLogin.Size = new Size(300, 34);
            FormHelper.StyleTextBox(txtLogin);

            Label lblPassword = new Label();
            lblPassword.Text = "Пароль";
            lblPassword.Font = new Font("Segoe UI", 9, FontStyle.Bold);
            lblPassword.ForeColor = FormHelper.DarkPastel;
            lblPassword.Location = new Point(50, 175);
            lblPassword.Size = new Size(300, 20);

            txtPassword = new TextBox();
            txtPassword.Font = new Font("Segoe UI", 11);
            txtPassword.Location = new Point(50, 200);
            txtPassword.Size = new Size(300, 34);
            txtPassword.UseSystemPasswordChar = true;
            FormHelper.StyleTextBox(txtPassword);

            btnLogin = new Button();
            btnLogin.Text = "Войти";
            btnLogin.Location = new Point(50, 260);
            btnLogin.Size = new Size(140, 40);
            FormHelper.StyleButton(btnLogin, FormHelper.SuccessPastel);
            btnLogin.Click += BtnLogin_Click;

            btnExit = new Button();
            btnExit.Text = "Выход";
            btnExit.Location = new Point(210, 260);
            btnExit.Size = new Size(140, 40);
            FormHelper.StyleButton(btnExit, FormHelper.GrayPastel);
            btnExit.Click += BtnExit_Click;

            this.Controls.Add(lblTitle);
            this.Controls.Add(lblLogin);
            this.Controls.Add(txtLogin);
            this.Controls.Add(lblPassword);
            this.Controls.Add(txtPassword);
            this.Controls.Add(btnLogin);
            this.Controls.Add(btnExit);
        }
    }
}