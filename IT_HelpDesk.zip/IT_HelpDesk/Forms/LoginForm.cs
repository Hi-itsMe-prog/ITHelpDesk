﻿using System;
using System.Windows.Forms;
using IT_HelpDesk.Services;
using IT_HelpDesk.Helpers;

namespace IT_HelpDesk.Forms
{
    public partial class LoginForm : Form
    {
        private AuthService _authService;

        public LoginForm()
        {
            _authService = new AuthService();
            InitializeComponent();
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            string login = txtLogin.Text.Trim();
            string password = txtPassword.Text;

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                FormHelper.ShowWarning("Введите логин и пароль!");
                return;
            }

            if (_authService.Login(login, password))
            {
                var currentUser = _authService.GetCurrentUser();
                Form mainForm;

                if (currentUser.Role == "ITSpecialist")
                    mainForm = new ITSpecialistForm(currentUser);
                else
                    mainForm = new EmployeeForm(currentUser);

                mainForm.Show();
                this.Hide();
            }
            else
            {
                FormHelper.ShowError("Неверный логин или пароль!");
                txtPassword.Clear();
                txtPassword.Focus();
            }
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}