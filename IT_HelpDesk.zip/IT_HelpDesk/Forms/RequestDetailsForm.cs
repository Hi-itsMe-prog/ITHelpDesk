﻿using System;
using System.Linq;
using System.Windows.Forms;
using IT_HelpDesk.Models;
using IT_HelpDesk.Services;
using IT_HelpDesk.Helpers;

namespace IT_HelpDesk.Forms
{
    public partial class RequestDetailsForm : Form
    {
        private int _requestId;
        private User _currentUser;
        private RequestService _requestService;

        public RequestDetailsForm(int requestId, User currentUser)
        {
            _requestId = requestId;
            _currentUser = currentUser;
            _requestService = new RequestService();
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            try
            {
                var request = _requestService.GetRequestById(_requestId);
                var solution = _requestService.GetSolutionByRequestId(_requestId);

                if (request != null)
                {
                    txtProblemDesc.Text = request.ProblemDesc;
                    txtStatus.Text = request.Status;
                    txtPriority.Text = request.PriorityName ?? "Не указан";
                    txtCategory.Text = request.CategoryName ?? "Не указана";
                    txtCreatedAt.Text = request.CreatedAt.ToString("dd.MM.yyyy HH:mm");
                }

                txtSolution.Text = solution?.SolutionText ?? "Решение еще не добавлено";

                LoadComments();
            }
            catch (Exception ex)
            {
                FormHelper.ShowError($"Ошибка: {ex.Message}");
            }
        }

        private void LoadComments()
        {
            var comments = _requestService.GetCommentsByRequestId(_requestId, _currentUser);
            dgvComments.DataSource = comments.ToList();

            if (dgvComments.Columns.Contains("AuthorName"))
                dgvComments.Columns["AuthorName"].HeaderText = "Автор";
            if (dgvComments.Columns.Contains("CommentText"))
                dgvComments.Columns["CommentText"].HeaderText = "Комментарий";
            if (dgvComments.Columns.Contains("Timestamp"))
                dgvComments.Columns["Timestamp"].HeaderText = "Дата";
        }

        private void BtnAddComment_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNewComment.Text))
            {
                FormHelper.ShowWarning("Введите текст комментария");
                return;
            }

            _requestService.AddComment(_requestId, _currentUser.Id, txtNewComment.Text);
            FormHelper.ShowInfo("Комментарий добавлен");
            txtNewComment.Clear();
            LoadComments();
        }
    }
}