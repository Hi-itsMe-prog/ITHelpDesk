﻿using System.Drawing;
using System.Windows.Forms;
using IT_HelpDesk.Helpers;

namespace IT_HelpDesk.Forms
{
    partial class RequestDetailsForm
    {
        private TextBox txtProblemDesc;
        private TextBox txtStatus;
        private TextBox txtPriority;
        private TextBox txtCategory;
        private TextBox txtCreatedAt;
        private TextBox txtSolution;
        private DataGridView dgvComments;
        private TextBox txtNewComment;
        private Button btnAddComment;

        private void InitializeComponent()
        {
            FormHelper.StyleForm(this);
            this.Size = new Size(800, 600);
            this.StartPosition = FormStartPosition.CenterParent;

            int y = 20;

            // Описание проблемы
            Label lblProblem = new Label();
            lblProblem.Text = "Описание проблемы:";
            lblProblem.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            lblProblem.Location = new Point(20, y);
            lblProblem.Size = new Size(150, 25);

            txtProblemDesc = new TextBox();
            txtProblemDesc.Location = new Point(180, y);
            txtProblemDesc.Size = new Size(580, 80);
            txtProblemDesc.Multiline = true;
            txtProblemDesc.ReadOnly = true;
            FormHelper.StyleTextBox(txtProblemDesc, true);
            y += 95;

            // Статус, приоритет, категория
            Label lblStatus = new Label();
            lblStatus.Text = "Статус:";
            lblStatus.Location = new Point(20, y);
            lblStatus.Size = new Size(100, 25);

            txtStatus = new TextBox();
            txtStatus.Location = new Point(130, y);
            txtStatus.Size = new Size(150, 34);
            txtStatus.ReadOnly = true;
            FormHelper.StyleTextBox(txtStatus);

            Label lblPriority = new Label();
            lblPriority.Text = "Приоритет:";
            lblPriority.Location = new Point(310, y);
            lblPriority.Size = new Size(80, 25);

            txtPriority = new TextBox();
            txtPriority.Location = new Point(400, y);
            txtPriority.Size = new Size(150, 34);
            txtPriority.ReadOnly = true;
            FormHelper.StyleTextBox(txtPriority);

            Label lblCategory = new Label();
            lblCategory.Text = "Категория:";
            lblCategory.Location = new Point(580, y);
            lblCategory.Size = new Size(80, 25);

            txtCategory = new TextBox();
            txtCategory.Location = new Point(670, y);
            txtCategory.Size = new Size(90, 34);
            txtCategory.ReadOnly = true;
            FormHelper.StyleTextBox(txtCategory);
            y += 50;

            // Дата создания
            Label lblCreated = new Label();
            lblCreated.Text = "Дата создания:";
            lblCreated.Location = new Point(20, y);
            lblCreated.Size = new Size(100, 25);

            txtCreatedAt = new TextBox();
            txtCreatedAt.Location = new Point(130, y);
            txtCreatedAt.Size = new Size(200, 34);
            txtCreatedAt.ReadOnly = true;
            FormHelper.StyleTextBox(txtCreatedAt);
            y += 60;

            // Решение
            Label lblSolution = new Label();
            lblSolution.Text = "Решение:";
            lblSolution.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            lblSolution.Location = new Point(20, y);
            lblSolution.Size = new Size(150, 25);

            txtSolution = new TextBox();
            txtSolution.Location = new Point(180, y);
            txtSolution.Size = new Size(580, 60);
            txtSolution.Multiline = true;
            txtSolution.ReadOnly = true;
            FormHelper.StyleTextBox(txtSolution, true);
            y += 80;

            // Комментарии
            Label lblComments = new Label();
            lblComments.Text = "Комментарии:";
            lblComments.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            lblComments.Location = new Point(20, y);
            lblComments.Size = new Size(150, 25);

            dgvComments = new DataGridView();
            dgvComments.Location = new Point(20, y + 30);
            dgvComments.Size = new Size(740, 200);
            FormHelper.ConfigureDataGridView(dgvComments);
            y += 250;

            // Добавление комментария
            txtNewComment = new TextBox();
            txtNewComment.Location = new Point(20, y);
            txtNewComment.Size = new Size(600, 34);
            FormHelper.StyleTextBox(txtNewComment);

            btnAddComment = new Button();
            btnAddComment.Text = "Добавить комментарий";
            btnAddComment.Location = new Point(640, y);
            btnAddComment.Size = new Size(120, 34);
            FormHelper.StyleButton(btnAddComment, FormHelper.PrimaryPastel);
            btnAddComment.Click += BtnAddComment_Click;
            y += 55;

            // Кнопка закрытия
            Button btnClose = new Button();
            btnClose.Text = "Закрыть";
            btnClose.Location = new Point(640, y);
            btnClose.Size = new Size(120, 40);
            FormHelper.StyleButton(btnClose, FormHelper.GrayPastel);
            btnClose.Click += (s, e) => this.Close();

            this.Controls.Add(lblProblem);
            this.Controls.Add(txtProblemDesc);
            this.Controls.Add(lblStatus);
            this.Controls.Add(txtStatus);
            this.Controls.Add(lblPriority);
            this.Controls.Add(txtPriority);
            this.Controls.Add(lblCategory);
            this.Controls.Add(txtCategory);
            this.Controls.Add(lblCreated);
            this.Controls.Add(txtCreatedAt);
            this.Controls.Add(lblSolution);
            this.Controls.Add(txtSolution);
            this.Controls.Add(lblComments);
            this.Controls.Add(dgvComments);
            this.Controls.Add(txtNewComment);
            this.Controls.Add(btnAddComment);
            this.Controls.Add(btnClose);
        }
    }
}