﻿using System;
using System.Security.Cryptography;
using System.Text;
using IT_HelpDesk.Models;
using IT_HelpDesk.Repositories;

namespace IT_HelpDesk.Services
{
    public class AuthService
    {
        private readonly UserRepository _userRepository;
        private User _currentUser;

        public AuthService()
        {
            _userRepository = new UserRepository();
        }

        public bool Login(string login, string password)
        {
            var user = _userRepository.GetByLogin(login);

            if (user != null && VerifyPassword(password, user.PasswordHash))
            {
                _currentUser = user;
                _userRepository.UpdateLastLogin(user.Id);
                return true;
            }

            return false;
        }

        public void Logout()
        {
            _currentUser = null;
        }

        public User GetCurrentUser()
        {
            return _currentUser;
        }

        public bool IsAuthenticated()
        {
            return _currentUser != null;
        }

        public bool IsITSpecialist()
        {
            return _currentUser != null && _currentUser.Role == "ITSpecialist";
        }

        public bool IsEmployee()
        {
            return _currentUser != null && _currentUser.Role == "Employee";
        }

        private bool VerifyPassword(string inputPassword, string storedHash)
        {
            // Простое сравнение для демо (в реальном проекте используй BCrypt)
            string inputHash = ComputeMd5Hash(inputPassword);
            return inputHash.Equals(storedHash, StringComparison.OrdinalIgnoreCase);
        }

        private string ComputeMd5Hash(string input)
        {
            using (MD5 md5 = MD5.Create())
            {
                byte[] inputBytes = Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);

                StringBuilder sb = new StringBuilder();
                foreach (byte b in hashBytes)
                {
                    sb.Append(b.ToString("x2"));
                }
                return sb.ToString();
            }
        }

        // Для реального проекта используй BCrypt:
        // Install-Package BCrypt.Net-Next
        /*
        private bool VerifyPassword(string inputPassword, string storedHash)
        {
            return BCrypt.Net.BCrypt.Verify(inputPassword, storedHash);
        }
        
        private string HashPassword(string password)
        {
            return BCrypt.Net.BCrypt.HashPassword(password);
        }
        */
    }
}