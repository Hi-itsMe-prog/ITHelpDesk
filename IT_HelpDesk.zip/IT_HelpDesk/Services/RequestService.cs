﻿using System;
using System.Collections.Generic;
using System.Linq;
using IT_HelpDesk.Models;
using IT_HelpDesk.Repositories;

namespace IT_HelpDesk.Services
{
    public class RequestService
    {
        private readonly RequestRepository _requestRepository;
        private readonly SolutionRepository _solutionRepository;
        private readonly CommentRepository _commentRepository;
        private readonly PriorityRepository _priorityRepository;
        private readonly CategoryRepository _categoryRepository;

        public RequestService()
        {
            _requestRepository = new RequestRepository();
            _solutionRepository = new SolutionRepository();
            _commentRepository = new CommentRepository();
            _priorityRepository = new PriorityRepository();
            _categoryRepository = new CategoryRepository();
        }

        // ===================== ЗАПРОСЫ =====================

        public IEnumerable<RequestViewModel> GetRequestsForUser(User currentUser)
        {
            if (currentUser.Role == "ITSpecialist")
            {
                return _requestRepository.GetAllRequestsWithDetails();
            }
            else
            {
                return _requestRepository.GetRequestsByUser(currentUser.Id);
            }
        }

        public Request GetRequestById(int id)
        {
            return _requestRepository.GetById(id);
        }

        public void CreateRequest(int userId, string problemDesc, int priorityId, int categoryId)
        {
            var request = new Request
            {
                UserId = userId,
                ProblemDesc = problemDesc,
                Status = "New",
                PriorityId = priorityId,
                CategoryId = categoryId,
                CreatedAt = DateTime.Now
            };

            _requestRepository.Add(request);
        }

        public void UpdateRequestStatus(int requestId, string newStatus)
        {
            _requestRepository.UpdateStatus(requestId, newStatus);
        }

        // ===================== РЕШЕНИЯ =====================

        public Solution GetSolutionByRequestId(int requestId)
        {
            return _solutionRepository.GetByRequestId(requestId);
        }

        public void AddSolution(int requestId, int itSpecialistId, string solutionText)
        {
            var solution = new Solution
            {
                RequestId = requestId,
                ItSpecialistId = itSpecialistId,
                SolutionText = solutionText,
                CompletedAt = DateTime.Now
            };

            _solutionRepository.Add(solution);
            _requestRepository.UpdateStatus(requestId, "Resolved");
        }

        public bool HasSolution(int requestId)
        {
            return _solutionRepository.HasSolution(requestId);
        }

        // ===================== КОММЕНТАРИИ =====================

        public IEnumerable<Comment> GetCommentsByRequestId(int requestId, User currentUser)
        {
            bool includeInternal = currentUser.Role == "ITSpecialist";
            return _commentRepository.GetCommentsByRequestId(requestId, includeInternal);
        }

        public void AddComment(int requestId, int authorId, string commentText)
        {
            var comment = new Comment
            {
                RequestId = requestId,
                AuthorId = authorId,
                CommentText = commentText,
                Timestamp = DateTime.Now,
                IsInternal = false
            };

            _commentRepository.Add(comment);
        }

        public void AddInternalComment(int requestId, int authorId, string commentText)
        {
            var comment = new Comment
            {
                RequestId = requestId,
                AuthorId = authorId,
                CommentText = commentText,
                Timestamp = DateTime.Now,
                IsInternal = true
            };

            _commentRepository.Add(comment);
        }

        // ===================== СПРАВОЧНИКИ =====================

        public IEnumerable<Priority> GetAllPriorities()
        {
            return _priorityRepository.GetAll();
        }

        public IEnumerable<Category> GetAllCategories()
        {
            return _categoryRepository.GetAll();
        }

        // ===================== СТАТИСТИКА =====================

        public int GetTotalRequestsCount()
        {
            var all = _requestRepository.GetAll();
            return all?.Count() ?? 0;
        }

        public int GetNewRequestsCount()
        {
            var newRequests = _requestRepository.GetRequestsByStatus("New");
            return newRequests?.Count() ?? 0;
        }

        public int GetRequestsByStatusCount(string status)
        {
            var requests = _requestRepository.GetRequestsByStatus(status);
            return requests?.Count() ?? 0;
        }
    }
}