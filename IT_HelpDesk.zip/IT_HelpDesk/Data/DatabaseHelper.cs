﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using Dapper;

namespace IT_HelpDesk.Data
{
    public static class DatabaseHelper
    {
        private static readonly string ConnectionString;

        static DatabaseHelper()
        {
            // Читаем строку подключения из app.config
            ConnectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
        }

        public static SqlConnection GetConnection()
        {
            return new SqlConnection(ConnectionString);
        }

        public static void TestConnection()
        {
            using (var connection = GetConnection())
            {
                try
                {
                    connection.Open();
                    Console.WriteLine("✅ Подключение к базе данных успешно!");
                }
                catch (Exception ex)
                {
                    throw new Exception($"❌ Ошибка подключения к БД: {ex.Message}");
                }
            }
        }

        // Вспомогательный метод для выполнения запросов без возврата данных
        public static int ExecuteNonQuery(string sql, object parameters = null)
        {
            using (var connection = GetConnection())
            {
                connection.Open();
                return connection.Execute(sql, parameters);
            }
        }

        // Вспомогательный метод для получения одного значения
        public static T ExecuteScalar<T>(string sql, object parameters = null)
        {
            using (var connection = GetConnection())
            {
                connection.Open();
                return connection.ExecuteScalar<T>(sql, parameters);
            }
        }
    }
}