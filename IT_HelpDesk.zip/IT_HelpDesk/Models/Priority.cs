﻿namespace IT_HelpDesk.Models
{
    public class Priority
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}