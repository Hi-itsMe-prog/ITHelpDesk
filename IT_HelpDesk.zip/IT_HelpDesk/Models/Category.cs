﻿namespace IT_HelpDesk.Models
{
    public class Category
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}