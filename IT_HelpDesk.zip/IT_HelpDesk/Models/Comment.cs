﻿using System;

namespace IT_HelpDesk.Models
{
    public class Comment
    {
        internal bool IsInternal;

        public int Id { get; set; }
        public int RequestId { get; set; }
        public int AuthorId { get; set; }
        public string CommentText { get; set; }
        public DateTime Timestamp { get; set; }

        public virtual Request Request { get; set; }
        public virtual User Author { get; set; }
    }
}