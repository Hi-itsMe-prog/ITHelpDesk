﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using IT_HelpDesk.Models;        // Для доступа к моделям
using IT_HelpDesk.Data;          // Для DatabaseHelper
using IT_HelpDesk.Repositories;  // Для репозиториев


namespace IT_HelpDesk
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Forms.LoginForm());
        }
    }
}
